import 'dart:io';
import 'package:firstproject/profile/user.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';


class UserModel extends ChangeNotifier{
  ImagePicker imagePicker = ImagePicker();
  User?_user;
  User?get user=>_user;
  Future <void> imageSelector(ImageSource source) async {
    XFile? image = await imagePicker.pickImage(source: source);
    if (image != null) {
      if (_user != null) {
        _user?.image = File(image!.path);
      }
      else {
        _user =
            User(name: "Hana",
                bio: "UI UX Designer",
                image: File(image!.path));
      }
      notifyListeners();
    }
  }

  void removeImage(){

    _user?.image=null;
    notifyListeners();
  }




}
