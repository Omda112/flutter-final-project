import 'package:firstproject/add_item/item_model.dart';
import 'package:firstproject/dashboard/dashboard_screen.dart';
import 'package:firstproject/add_item/add_item_screen.dart';
import 'package:firstproject/dashboard/nav_bar.dart';
import 'package:firstproject/favorite/favorite_model.dart';
import 'package:firstproject/profile/user_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    MultiProvider(providers: [

      ChangeNotifierProvider(
        create: (context) => UserModel(),
      ),

      ChangeNotifierProvider(
        create: (context) => ItemModel(),
      ),

      ChangeNotifierProvider(
        create: (context) => FavoriteModel(),
      ),

    ],
        child: MyApp(),
    )

  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: NavBar(),
    );
  }
}
